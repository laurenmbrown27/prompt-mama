PROMPT MAMA — PRESS KIT BUNDLE
=================================
Updated: April 2026
Press contact: hello@promptmama.com

WHAT'S INSIDE
-------------
bios/                     Three bio lengths + one-liner
  bio-short-50w.txt
  bio-medium-100w.txt
  bio-long-250w.txt

logos/
  prompt-mama-logo.png    Transparent PNG, 600x478

photos/
  lauren-howard-headshot.jpg    900x947, ~120KB
  lauren-howard-headshot.webp   smaller modern format

social/
  social-share-card.png   1200x630 OG image for previews

quick-facts.txt           Producer-friendly fact sheet
speaking-topics.txt       Topics Lauren is happy to lead

USAGE
-----
Logo, photos, and social card are licensed for editorial use
in coverage of Lauren Howard / Prompt Mama / CAEVO. Please don't
modify the logo or photos. For any other use (advertising,
products, etc.), email hello@promptmama.com first.

The full press kit lives at: https://promptmama.com/press-kit.html
